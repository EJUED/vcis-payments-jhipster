package com.mycompany.myapp.domain.enumeration;

/**
 * The HistoryOriginEnum enumeration.
 */
public enum HistoryOriginEnum {
    POD,
    Vendas,
    RecebimentoDeGraos,
}
