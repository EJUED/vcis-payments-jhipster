package com.mycompany.myapp.domain.enumeration;

/**
 * The InvoicesStatusEnum enumeration.
 */
public enum InvoicesStatusEnum {
    Send,
    Approved,
    Rejected,
}
