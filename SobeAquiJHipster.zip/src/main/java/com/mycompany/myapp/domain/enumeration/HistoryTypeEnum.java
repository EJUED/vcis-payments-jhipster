package com.mycompany.myapp.domain.enumeration;

/**
 * The HistoryTypeEnum enumeration.
 */
public enum HistoryTypeEnum {
    TaxaDeBaixaDeVolumeDeIsencao,
    PrecoDaTecnologiaNaMoega,
    SeasonBonus,
    Vendas,
}
